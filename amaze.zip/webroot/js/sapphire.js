$(window).on('load', function () 
{
	$('.selectpicker').selectpicker({});
});
